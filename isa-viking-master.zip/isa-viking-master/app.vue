<template>
  <div>
    <NuxtPage /> 
</div>
</template>

<style>
body{
  font-family: "Jockey One", sans-serif;
}
</style>
