<script setup>
</script>

<template>
    <UCard>
        <template #header>
            <Placeholder class="h-8" />
        </template>

        <div>
            <span>Articoli perfetti</span>
        </div>

        <template #footer>
            <Placeholder class="h-8" />
        </template>
    </UCard>
</template>

<style>
</style>